﻿using System;

namespace DriverControllApp.Models
{
    public class RegisteredUsers
    {
        public int accountId { get; set; }

        public string login { get; set; }

        public string password { get; set; }

        public string name { get; set; }

        public string accountType { get; set; }

    }
}


